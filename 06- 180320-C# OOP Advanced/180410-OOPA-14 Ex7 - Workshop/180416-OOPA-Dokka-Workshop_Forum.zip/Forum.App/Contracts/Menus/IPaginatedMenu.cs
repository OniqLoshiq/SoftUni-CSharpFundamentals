﻿namespace Forum.App.Contracts
{
    public interface IPaginatedMenu
    {
		void ChangePage(bool forward = true);
    }
}
