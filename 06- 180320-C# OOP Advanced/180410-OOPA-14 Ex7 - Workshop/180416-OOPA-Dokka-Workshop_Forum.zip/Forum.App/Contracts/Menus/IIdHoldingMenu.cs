﻿namespace Forum.App.Contracts
{
    public interface IIdHoldingMenu : IMenu
    {
		void SetId(int id);
    }
}
