﻿public class MachineGun : Ammunition
{
    private const double WeightValue = 10.6;
    public override double Weight => WeightValue;
}
