﻿public class Knife : Ammunition
{
    private const double WeightValue = 0.4;
    public override double Weight => WeightValue;
}
