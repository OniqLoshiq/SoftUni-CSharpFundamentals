﻿public class Gun : Ammunition
{
    private const double WeightValue = 1.4d;
    public override double Weight => WeightValue;
}