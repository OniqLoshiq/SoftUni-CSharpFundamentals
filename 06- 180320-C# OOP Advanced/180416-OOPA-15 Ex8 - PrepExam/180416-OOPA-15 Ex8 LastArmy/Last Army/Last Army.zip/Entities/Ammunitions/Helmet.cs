﻿public class Helmet : Ammunition
{
    private const double WeightValue = 2.3;
    public override double Weight => WeightValue;
}
