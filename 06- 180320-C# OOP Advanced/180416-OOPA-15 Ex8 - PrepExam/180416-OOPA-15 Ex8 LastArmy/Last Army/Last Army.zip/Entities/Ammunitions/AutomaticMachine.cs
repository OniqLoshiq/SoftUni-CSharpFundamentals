﻿public class AutomaticMachine : Ammunition
{
    private const double WeightValue = 6.3;
    public override double Weight => WeightValue;
}