﻿public class NightVision : Ammunition
{
    private const double WeightValue = 0.8;
    public override double Weight => WeightValue;
}