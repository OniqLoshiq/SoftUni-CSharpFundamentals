﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Logger.Model.Interfaces
{
    public interface ILogConsole
    {
        void WriteLine(string text);
    }
}
