﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Logger.Model.Interfaces
{
    public interface IFormatable
    {
        string Format { get; }
    }
}
