﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IPet
{
    string Name { get; }
    int Age { get; }
    string Kind { get; }
}
