﻿namespace DungeonsAndCodeWizards.Models.Factions
{
    public enum Faction
    {
        CSharp, Java
    }
}
