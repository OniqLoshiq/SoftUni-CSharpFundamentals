﻿using System;

namespace _03_Ferrari
{
    class Program
    {
        static void Main(string[] args)
        {
            var ferrari = new Ferrari(Console.ReadLine());
            Console.WriteLine(ferrari);
        }
    }
}
