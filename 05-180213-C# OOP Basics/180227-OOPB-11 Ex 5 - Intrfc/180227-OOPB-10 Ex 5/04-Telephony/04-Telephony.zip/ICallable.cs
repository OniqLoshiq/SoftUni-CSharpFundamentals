﻿public interface ICallable
{
    string Calling(string number);
}
