﻿public interface IBrowsable
{
    string Browse(string url);
}
