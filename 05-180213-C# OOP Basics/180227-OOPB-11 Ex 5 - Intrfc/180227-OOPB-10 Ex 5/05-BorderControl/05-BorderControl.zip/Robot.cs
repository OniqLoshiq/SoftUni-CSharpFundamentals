﻿public class Robot : EnteringObject
{
    public Robot(string name, string id) : base(name, id)
    {
    }
}
