﻿public interface ISonicHarvester
{
    int SonicFactor { get; }
}
