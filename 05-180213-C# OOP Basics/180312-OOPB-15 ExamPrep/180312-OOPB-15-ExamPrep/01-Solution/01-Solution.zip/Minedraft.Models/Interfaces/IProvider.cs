﻿public interface IProvider
{
    string Id { get; }
    double EnergyOutput { get; }
}
